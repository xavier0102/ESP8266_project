esto es otro que encontre para autoconect con mqtt, la migracion la hice del readme anterios

https://github.com/CurlyWurly-1/ESP8266-WIFIMANAGER-MQTT/blob/master/MQTT_with_WiFiManager.ino