medidor de bateria
-te esta pagina saque la coneccion directa de puerto analogico para el valor de potencial de la bateria  https://groups.google.com/forum/#!topic/souliss-es/7sOINMQh4NE
-de esta saque el codigo para el programa e hice los cambios pertinentes https://programarfacil.com/blog/arduino-blog/medidor-de-carga-de-baterias-pilas-arduino/