modes de estados del ESP8266

deep mode ejemplos

http://www.esploradores.com/practica-9-modos-de-ahorro-de-energia-deep-sleep/
https://randomnerdtutorials.com/esp8266-deep-sleep-with-arduino-ide/
http://arduinoamuete.blogspot.com/2017/01/modo-deep-sleep-en-esp8266.html